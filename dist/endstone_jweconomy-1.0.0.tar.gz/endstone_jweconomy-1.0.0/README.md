# JWEconomy

JWEconomy is a robust, lightweight, and highly performant multi-currency economy plugin for Minecraft Bedrock, built specifically for the **Endstone API**. 

It provides server administrators with a fully-featured monetary system that is easy to manage, fast, and scalable, supporting everything from local SQLite databases to large MySQL/MariaDB networks.

---

## 🌟 Key Features

- **Multi-Currency System:** Create and manage custom currencies (Coins, Gems, Tokens, etc.) effortlessly.
- **Physical Bank Notes (`/withdraw`):** Players can withdraw their digital balance into a physical item (like a Paper note or Emerald voucher) and trade it safely. Right-click to redeem!
- **High-Performance Database:** Supports local **SQLite** (WAL mode) and remote **MariaDB/MySQL** connection pools.
- **Data Import Tools:** Easily migrate your data from other plugins using `/eco import mysql` or `/eco import sqlite`.
- **Smart Memory Caching:** Balances are cached in memory for instant retrieval, preventing server lag.
- **Configurable Taxation:** Combat inflation by applying a tax percentage on player-to-player transfers (`/pay`).
- **Leaderboards (`/eco top`):** Competitive ranking system showing the richest players for each currency.
- **100% Customizable:** Every message, currency symbol, and format can be changed in `messages.yml`.

---

## 🛠️ Commands & Permissions

*Note: `[currency]` is always optional. If you don't type it, the plugin uses the default currency (e.g., `coins`).*

| Command | Permission | Description |
|---|---|---|
| `/balance [player] [currency]` | `jweconomy.command.balance` | Check your own balance or someone else's. |
| `/pay <player> <amount> [currency]` | `jweconomy.command.pay` | Transfer money to another player. |
| `/withdraw <amount> [currency]` | `jweconomy.command.withdraw` | Withdraw your digital balance into a physical item. |
| `/eco top [page] [currency]` | `jweconomy.command.eco` | View the richest players leaderboard. |
| `/eco give <player> <amount> [curr]`| `jweconomy.admin` | **(Admin)** Add money to a player. |
| `/eco take <player> <amount> [curr]`| `jweconomy.admin` | **(Admin)** Deduct money from a player. |
| `/eco set <player> <amount> [curr]` | `jweconomy.admin` | **(Admin)** Set a player's balance to an exact amount. |
| `/eco reload` | `jweconomy.admin` | **(Admin)** Reload the config and messages files. |
| `/eco import mysql <host>...` | `jweconomy.admin` | **(Admin)** Import data from a MySQL database. |
| `/eco import sqlite <file_path>` | `jweconomy.admin` | **(Admin)** Import data from an SQLite file. |

---

## 💻 Developer API (For Plugin Creators)

JWEconomy exposes a robust API for developers to integrate the economy into their own plugins (e.g., Shops, Auction Houses, Kits).

### ⚠️ Understanding Asynchronous Calls
Endstone API is generally **synchronous** (runs on the main thread). However, JWEconomy uses an **asynchronous** database to prevent lag. 
This means **you cannot call `api.add_balance()` directly inside a command or event**. You must create an `async def` function and run it using JWEconomy's async thread.

### 📖 Step-by-Step Example (A Simple Shop Plugin)

Here is a complete, copy-pasteable example of how to hook into JWEconomy safely:

```python
from endstone.plugin import Plugin
from endstone.command import CommandSender, Command
from endstone import Player
from endstone.inventory import ItemStack

class MyShopPlugin(Plugin):
    prefix = "MyShop"
    api_version = "0.10"

    commands = {
        "buyapple": {
            "description": "Buy an apple for 50 coins",
            "usages": ["/buyapple"]
        }
    }

    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        if not isinstance(sender, Player):
            return False

        # 1. Get the JWEconomy Plugin & API
        jweco = self.server.plugin_manager.get_plugin("jweconomy")
        if not jweco:
            sender.send_message("§cJWEconomy is not installed!")
            return True
            
        api = jweco.get_api()
        player_uuid = str(sender.unique_id)
        price = 50.0
        currency = "coins" # Optional: leave as None to use default

        # 2. Define your asynchronous task
        async def process_purchase():
            try:
                # Check if player has enough money
                has_money = await api.has_balance(player_uuid, price, currency)
                
                if not has_money:
                    # IMPORTANT: Use scheduler to send messages/modify inventory on the main thread!
                    self.server.scheduler.run_task(self, lambda: sender.send_message("§cYou don't have enough coins!"))
                    return

                # Deduct the money
                await api.remove_balance(player_uuid, price, currency)

                # Give the item (Must be on the main thread)
                def give_item():
                    sender.inventory.add_item(ItemStack("minecraft:apple"))
                    sender.send_message("§aYou bought an Apple for 50 coins!")
                
                self.server.scheduler.run_task(self, give_item)

            except Exception as e:
                self.logger.error(f"Transaction error: {e}")

        # 3. Run the async task using JWEconomy's built-in async loop
        jweco.run_async(process_purchase())
        
        return True
```

### 📚 Available API Methods

All methods are `async` and must be `await`ed inside an async function. They all accept an optional `currency: str` argument. If omitted, it uses the server's default currency.

| Method | Description | Returns |
|--------|-------------|---------|
| `await api.get_balance(uuid, [currency])` | Get a player's balance. | `float` |
| `await api.has_balance(uuid, amount, [currency])` | Check if player has at least `amount`. | `bool` |
| `await api.add_balance(uuid, amount, [currency])` | Add money to player. | `float` (new balance) |
| `await api.remove_balance(uuid, amount, [currency])` | Remove money from player. | `float` (new balance) or `None` if insufficient. |
| `await api.set_balance(uuid, amount, [currency])` | Set exact balance. | `float` (new balance) |
| `await api.transfer_balance(sender_uuid, receiver_uuid, amount, [currency])` | Safely transfer money (applies taxes). | `TransferResult` object |

**Utility (Synchronous) Methods:**
You can call these directly anywhere without `async/await`.
- `api.get_currency_symbol("gems")` -> Returns `"💎"`
- `api.get_currency_name("coins")` -> Returns `"Coins"`
- `api.get_currency_name_plural("coins")` -> Returns `"Coins"`